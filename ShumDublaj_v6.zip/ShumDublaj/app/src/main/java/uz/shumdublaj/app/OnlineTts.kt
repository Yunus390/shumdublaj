package uz.shumdublaj.app

/** Eski Edge TTS mijozi olib tashlandi (Microsoft v2 tokenni majburiy qildi). Aisha: AishaTts.kt */
object OnlineTts
