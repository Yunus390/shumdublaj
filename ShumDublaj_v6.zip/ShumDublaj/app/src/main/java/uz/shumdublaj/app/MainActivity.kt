package uz.shumdublaj.app

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.switchmaterial.SwitchMaterial
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var keyInput: EditText
    private lateinit var statusView: TextView
    private lateinit var playerView: YouTubePlayerView
    private lateinit var dubSwitch: SwitchMaterial

    private var player: YouTubePlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsOk = false

    private var segs: List<Seg> = emptyList()
    private var audioFiles: Map<Int, File> = emptyMap()
    private var mp: MediaPlayer? = null
    private var currentVideoId = ""
    private var fetchedUpTo = 0
    private var fetching = false
    private var idx = 0
    private var pendingVideoId: String? = null
    private var loadJob: Job? = null

    // Panel qiymatlari (foiz)
    private var quiet = 45     // Asl ovoz
    private var duck = 8       // Gapirganda asl ovoz
    private var dubVol = 100   // Dublyaj ovozi
    private var dubOn = true
    @Volatile private var speaking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        keyInput = findViewById(R.id.keyInput)
        statusView = findViewById(R.id.status)
        playerView = findViewById(R.id.playerView)
        dubSwitch = findViewById(R.id.dubSwitch)

        keyInput.setText(getSharedPreferences("prefs", Context.MODE_PRIVATE).getString("aisha_key", "") ?: "")

        lifecycle.addObserver(playerView)
        playerView.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
            override fun onReady(youTubePlayer: YouTubePlayer) {
                player = youTubePlayer
                pendingVideoId?.let { youTubePlayer.cueVideo(it, 0f) }
            }

            override fun onStateChange(youTubePlayer: YouTubePlayer, state: PlayerConstants.PlayerState) {
                when (state) {
                    PlayerConstants.PlayerState.PAUSED,
                    PlayerConstants.PlayerState.ENDED -> stopSpeech()
                    PlayerConstants.PlayerState.PLAYING -> if (!speaking) applyBaseVolume()
                    else -> {}
                }
            }

            override fun onCurrentSecond(youTubePlayer: YouTubePlayer, second: Float) = tick(second)
        })

        initTts()
        setupPanel()

        findViewById<Button>(R.id.loadBtn).setOnClickListener { startLoad(urlInput.text.toString()) }
        findViewById<Button>(R.id.ttsBtn).setOnClickListener {
            try {
                startActivity(Intent("com.android.settings.TTS_SETTINGS"))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }

        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            urlInput.setText(text)
            startLoad(text)
        }
    }

    // ---------- Panel ----------
    private fun setupPanel() {
        fun bind(barId: Int, labelId: Int, name: String, set: (Int) -> Unit) {
            val bar = findViewById<SeekBar>(barId)
            val label = findViewById<TextView>(labelId)
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = "$name: $p%"
                    set(p)
                    if (!speaking) applyBaseVolume() else player?.setVolume(duck)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        bind(R.id.quietBar, R.id.quietLabel, "Asl ovoz") { quiet = it }
        bind(R.id.duckBar, R.id.duckLabel, "Gapirganda asl ovoz") { duck = it }
        bind(R.id.dubBar, R.id.dubLabel, "Dublyaj ovozi") { dubVol = it }

        dubSwitch.setOnCheckedChangeListener { _, checked ->
            dubOn = checked
            if (!checked) stopSpeech()
            applyBaseVolume()
        }
    }

    private fun applyBaseVolume() {
        player?.setVolume(if (dubOn) quiet else 100)
    }

    // ---------- Yuklash ----------
    private fun extractId(input: String): String? {
        val s = input.trim()
        if (Regex("^[A-Za-z0-9_-]{11}$").matches(s)) return s
        return Regex("(?:v=|youtu\\.be/|shorts/|embed/|live/)([A-Za-z0-9_-]{11})")
            .find(s)?.groupValues?.get(1)
    }

    private fun apiKey(): String {
        val typed = keyInput.text.toString().trim()
        if (typed.isNotBlank()) return typed
        return getSharedPreferences("prefs", Context.MODE_PRIVATE).getString("aisha_key", "")?.trim() ?: ""
    }

    private fun startLoad(input: String) {
        val id = extractId(input)
        if (id == null) {
            setStatus("Havola tushunarsiz. YouTube havolasini qo'ying.")
            return
        }
        if (keyInput.text.toString().trim().isNotBlank())
            getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putString("aisha_key", keyInput.text.toString().trim()).apply()

        stopSpeech()
        segs = emptyList()
        audioFiles = emptyMap()
        idx = 0
        fetchedUpTo = 0
        fetching = false
        currentVideoId = id
        pendingVideoId = id
        player?.cueVideo(id, 0f)

        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            try {
                val result = Captions.loadUzbek(id) { msg -> runOnUiThread { setStatus(msg) } }
                segs = result
                idx = 0
                if (ttsOk) {
                    setStatus("Tayyor: ${result.size} ta bo'lak (telefon ovozi). Play bosing.")
                    return@launch
                }
                val key = apiKey()
                if (key.isBlank()) {
                    setStatus("Tarjima tayyor (${result.size} bo'lak), lekin ovoz uchun Aisha API kaliti kerak: space.aisha.group dan oling, yuqoridagi maydonga qo'ying va qayta bosing.")
                    return@launch
                }
                val to = minOf(result.size, 40)
                fetchedUpTo = to
                setStatus("Ovoz tayyorlanmoqda (0/$to)…")
                audioFiles = AishaTts.prefetch(cacheDir, id, key, result, 0 until to) { n, t ->
                    runOnUiThread { setStatus("Ovoz tayyorlanmoqda ($n/$t)…") }
                }
                setStatus(
                    if (audioFiles.isEmpty()) "Ovoz olinmadi: ${AishaTts.lastError}"
                    else "Tayyor: ${audioFiles.size}/$to bo'lak ovozlandi. Play bosing (qolgani video bilan birga tayyorlanadi)."
                )
            } catch (e: Exception) {
                setStatus("Xato: ${e.message}")
            }
        }
    }

    private var lastFailMs = 0L

    /** Video oldinga siljigan sari keyingi bo'laklar ovozini yuklab turadi (kreditni tejaydi). */
    private fun ensureAhead(i: Int) {
        if (ttsOk || fetching || segs.isEmpty()) return
        val key = apiKey()
        if (key.isBlank() || fetchedUpTo >= segs.size) return
        if (i + 25 < fetchedUpTo) return
        if (System.currentTimeMillis() - lastFailMs < 15000) return
        val from = maxOf(fetchedUpTo, i)
        val to = minOf(segs.size, from + 50)
        val vid = currentVideoId
        val list = segs
        fetching = true
        AishaTts.lastError = ""
        setStatus("Keyingi bo'laklar ovozi tayyorlanmoqda…")
        lifecycleScope.launch {
            val m = AishaTts.prefetch(cacheDir, vid, key, list, from until to) { _, _ -> }
            if (vid == currentVideoId) {
                if (m.isEmpty()) {
                    lastFailMs = System.currentTimeMillis()
                    setStatus("Keyingi ovozni olib bo'lmadi: ${AishaTts.lastError.ifBlank { "noma'lum xato" }}")
                } else {
                    audioFiles = audioFiles + m
                    fetchedUpTo = to
                    setStatus("Ovoz tayyor: ${to}/${list.size} bo'lakkacha.")
                }
            }
            fetching = false
        }
    }

    // ---------- Dublyaj ----------
    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("uz", "UZ"))
                ttsOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        speaking = true
                        runOnUiThread { player?.setVolume(duck) }
                    }
                    override fun onDone(utteranceId: String?) {
                        speaking = false
                        runOnUiThread { applyBaseVolume() }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        speaking = false
                        runOnUiThread { applyBaseVolume() }
                    }
                })
            }
        }
    }

    private fun tick(t: Float) {
        if (!dubOn || segs.isEmpty()) return
        // Orqaga o'tkazilgan bo'lsa — indeksni qayta hisoblaymiz
        if (idx > 0 && idx <= segs.size && t < segs[idx - 1].start - 0.5f) {
            stopSpeech()
            idx = segs.indexOfFirst { it.start >= t - 1.5f }.let { if (it < 0) segs.size else it }
        }
        // Oldinga o'tkazilgan bo'lsa — o'tib ketgan bo'laklarni tashlab yuboramiz
        while (idx < segs.size && segs[idx].start < t - 1.5f) idx++
        ensureAhead(idx)
        if (!ttsOk && audioFiles.isEmpty()) return
        if (idx < segs.size && segs[idx].start <= t) {
            speak(segs[idx], idx)
            idx++
        }
    }

    private fun speakOnline(seg: Seg, id: Int) {
        val f = audioFiles[id] ?: return
        stopOnline()
        try {
            val p = MediaPlayer()
            p.setDataSource(f.absolutePath)
            p.setOnPreparedListener { m ->
                val dur = (seg.end - seg.start).coerceAtLeast(0.8f)
                val speed = ((m.duration / 1000f) / dur).coerceIn(1.0f, 1.6f)
                try { m.playbackParams = m.playbackParams.setSpeed(speed) } catch (e: Exception) {}
                m.setVolume(dubVol / 100f, dubVol / 100f)
                speaking = true
                player?.setVolume(duck)
                m.start()
            }
            p.setOnCompletionListener { m ->
                speaking = false
                applyBaseVolume()
                m.release()
                if (mp === m) mp = null
            }
            p.setOnErrorListener { m, _, _ ->
                speaking = false
                applyBaseVolume()
                m.release()
                if (mp === m) mp = null
                true
            }
            mp = p
            p.prepareAsync()
        } catch (e: Exception) {
            speaking = false
        }
    }

    private fun stopOnline() {
        mp?.let {
            try { it.stop() } catch (e: Exception) {}
            it.release()
        }
        mp = null
    }

    private fun speak(seg: Seg, id: Int) {
        if (!ttsOk) { speakOnline(seg, id); return }
        val engine = tts ?: return
        val dur = (seg.end - seg.start).coerceAtLeast(0.8f)
        val charsPerSec = 14f
        val rate = (seg.text.length / (dur * charsPerSec)).coerceIn(0.9f, 1.9f)
        engine.setSpeechRate(rate)
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, dubVol / 100f)
        }
        engine.speak(seg.text, TextToSpeech.QUEUE_FLUSH, params, "seg$id")
    }

    private fun stopSpeech() {
        tts?.stop()
        stopOnline()
        speaking = false
        applyBaseVolume()
    }

    private fun setStatus(s: String) {
        statusView.text = s
    }

    override fun onDestroy() {
        stopOnline()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
