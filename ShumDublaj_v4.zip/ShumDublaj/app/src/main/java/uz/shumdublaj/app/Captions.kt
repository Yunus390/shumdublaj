package uz.shumdublaj.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Bitta dublyaj bo'lagi: boshlanish/tugash (soniya) va o'zbekcha matn. */
data class Seg(val start: Float, val end: Float, val text: String)

object Captions {
    private const val CLIENT_VERSION = "20.10.38"
    private const val UA = "com.google.android.youtube/$CLIENT_VERSION (Linux; U; Android 14) gzip"

    /** YouTube subtitrini oladi va o'zbekchaga tarjima qiladi. */
    suspend fun loadUzbek(videoId: String, onStatus: (String) -> Unit): List<Seg> =
        withContext(Dispatchers.IO) {
            onStatus("Subtitr olinmoqda…")
            val raw = fetchCaptions(videoId)
            if (raw.isEmpty()) throw Exception("Bu videoda subtitr topilmadi")
            val merged = merge(raw)

            onStatus("O'zbekchaga tarjima qilinmoqda (0/${merged.size})…")
            val sem = Semaphore(6)
            var done = 0
            val translated = coroutineScope {
                merged.map { seg ->
                    async {
                        sem.withPermit {
                            val t = translate(seg.text)
                            done++
                            if (done % 10 == 0) onStatus("O'zbekchaga tarjima qilinmoqda ($done/${merged.size})…")
                            seg.copy(text = t)
                        }
                    }
                }.awaitAll()
            }
            translated.filter { it.text.isNotBlank() }
        }

    private fun fetchCaptions(videoId: String): List<Seg> {
        val body = JSONObject()
            .put(
                "context", JSONObject().put(
                    "client", JSONObject()
                        .put("clientName", "ANDROID")
                        .put("clientVersion", CLIENT_VERSION)
                        .put("androidSdkVersion", 34)
                        .put("hl", "en")
                )
            )
            .put("videoId", videoId)
            .toString()

        val player = JSONObject(http("https://www.youtube.com/youtubei/v1/player?prettyPrint=false", body))
        val tracks = player.optJSONObject("captions")
            ?.optJSONObject("playerCaptionsTracklistRenderer")
            ?.optJSONArray("captionTracks")
            ?: throw Exception("Bu videoda subtitr topilmadi (yoki YouTube so'rovni rad etdi)")

        // Qo'lda yozilgan subtitr bo'lsa o'shani, bo'lmasa avtomatik (asr) ni olamiz
        var manual: JSONObject? = null
        for (i in 0 until tracks.length()) {
            val t = tracks.getJSONObject(i)
            if (t.optString("kind") != "asr") { manual = t; break }
        }
        val chosen: JSONObject = manual ?: tracks.getJSONObject(0)

        val url = chosen.getString("baseUrl").replace("&fmt=srv3", "") + "&fmt=json3"
        val events = JSONObject(http(url, null)).optJSONArray("events") ?: return emptyList()

        val out = mutableListOf<Seg>()
        for (i in 0 until events.length()) {
            val e = events.getJSONObject(i)
            val segs = e.optJSONArray("segs") ?: continue
            val sb = StringBuilder()
            for (j in 0 until segs.length()) sb.append(segs.getJSONObject(j).optString("utf8"))
            val text = sb.toString().replace("\n", " ").trim()
            if (text.isEmpty()) continue
            val start = e.optLong("tStartMs") / 1000f
            val end = start + e.optLong("dDurationMs", 2000L) / 1000f
            out.add(Seg(start, end, text))
        }
        return out
    }

    /** Qisqa bo'laklarni gap darajasida birlashtiradi (tarjima sifati va ovoz uchun yaxshiroq). */
    private fun merge(raw: List<Seg>): List<Seg> {
        val out = mutableListOf<Seg>()
        var cs = 0f
        var ce = 0f
        val sb = StringBuilder()
        fun flush() {
            if (sb.isNotBlank()) out.add(Seg(cs, ce, sb.toString().trim()))
            sb.clear()
        }
        for (r in raw) {
            if (sb.isEmpty()) cs = r.start
            sb.append(' ').append(r.text)
            ce = r.end
            val t = sb.toString().trimEnd()
            if (ce - cs >= 3.5f || t.endsWith(".") || t.endsWith("?") || t.endsWith("!")) flush()
        }
        flush()
        // Keyingi gap boshlanishidan oshib ketmasin
        return out.mapIndexed { i, s ->
            val limit = if (i + 1 < out.size) out[i + 1].start else s.end
            s.copy(end = minOf(s.end, limit).coerceAtLeast(s.start + 0.8f))
        }
    }

    private fun translate(text: String): String {
        val q = URLEncoder.encode(text, "UTF-8")
        val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=uz&dt=t&q=$q"
        var lastErr: Exception? = null
        repeat(3) {
            try {
                val arr = JSONArray(http(url, null)).getJSONArray(0)
                val sb = StringBuilder()
                for (i in 0 until arr.length()) sb.append(arr.getJSONArray(i).optString(0))
                return sb.toString().trim()
            } catch (e: Exception) {
                lastErr = e
                Thread.sleep(400)
            }
        }
        throw Exception("Tarjima xatosi: ${lastErr?.message}")
    }

    private fun http(url: String, postBody: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", UA)
        if (postBody != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("X-YouTube-Client-Name", "3")
            c.setRequestProperty("X-YouTube-Client-Version", CLIENT_VERSION)
            c.outputStream.use { it.write(postBody.toByteArray()) }
        }
        val code = c.responseCode
        if (code !in 200..299) {
            val err = try { c.errorStream?.bufferedReader()?.use { it.readText() }?.take(160) } catch (e: Exception) { null }
            throw Exception("HTTP $code ${err ?: ""}".trim())
        }
        return c.inputStream.bufferedReader().use { it.readText() }
    }
}
