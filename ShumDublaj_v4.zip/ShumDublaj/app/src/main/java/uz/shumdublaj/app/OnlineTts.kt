package uz.shumdublaj.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Microsoft Edge "Read Aloud" neyron ovozi (uz-UZ-MadinaNeural) — kalitsiz, bepul.
 * Rasmiy bo'lmagan xizmat: Microsoft istalgan vaqt o'zgartirishi mumkin.
 */
object OnlineTts {
    private const val TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
    private const val GEC_VERSION = "1-143.0.3650.75"
    private const val VOICE = "uz-UZ-MadinaNeural"
    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0"

    @Volatile var lastError: String = ""

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun gec(): String {
        var ticks = System.currentTimeMillis() / 1000 + 11644473600L
        ticks -= ticks % 300
        val intervals = ticks * 10_000_000L
        val hash = MessageDigest.getInstance("SHA-256").digest("$intervals$TOKEN".toByteArray())
        return hash.joinToString("") { "%02X".format(it) }
    }

    private fun stamp(): String {
        val f = SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss 'GMT+0000 (Coordinated Universal Time)'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date())
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")

    /** Bitta matnni mp3 baytlarga aylantiradi. */
    private fun synthesize(text: String, ratePercent: Int): ByteArray {
        val connId = UUID.randomUUID().toString().replace("-", "")
        val url = "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1" +
            "?TrustedClientToken=$TOKEN&ConnectionId=$connId&Sec-MS-GEC=${gec()}&Sec-MS-GEC-Version=$GEC_VERSION"
        val req = Request.Builder().url(url)
            .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .header("User-Agent", UA)
            .header("Pragma", "no-cache")
            .header("Cache-Control", "no-cache")
            .build()

        val audio = ByteArrayOutputStream()
        val latch = CountDownLatch(1)
        var error: String? = null

        val ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val config = "X-Timestamp:${stamp()}\r\nContent-Type:application/json; charset=utf-8\r\n" +
                    "Path:speech.config\r\n\r\n" +
                    "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":{\"sentenceBoundaryEnabled\":\"false\"," +
                    "\"wordBoundaryEnabled\":\"false\"},\"outputFormat\":\"audio-24khz-48kbitrate-mono-mp3\"}}}}\r\n"
                webSocket.send(config)
                val sign = if (ratePercent >= 0) "+$ratePercent" else "$ratePercent"
                val ssml = "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='uz-UZ'>" +
                    "<voice name='$VOICE'><prosody pitch='+0Hz' rate='$sign%' volume='+0%'>${esc(text)}</prosody></voice></speak>"
                val msg = "X-RequestId:${UUID.randomUUID().toString().replace("-", "")}\r\n" +
                    "Content-Type:application/ssml+xml\r\nX-Timestamp:${stamp()}Z\r\nPath:ssml\r\n\r\n$ssml"
                webSocket.send(msg)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.contains("Path:turn.end")) {
                    latch.countDown()
                    webSocket.close(1000, null)
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val b = bytes.toByteArray()
                if (b.size < 2) return
                val headerLen = ((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)
                if (b.size < 2 + headerLen) return
                val header = String(b, 2, headerLen)
                if (header.contains("Path:audio")) {
                    audio.write(b, 2 + headerLen, b.size - 2 - headerLen)
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                error = "${response?.code ?: ""} ${t.message ?: t.javaClass.simpleName}".trim()
                latch.countDown()
            }
        })

        val ok = latch.await(25, TimeUnit.SECONDS)
        if (!ok) { ws.cancel(); throw Exception("vaqt tugadi") }
        error?.let { throw Exception(it) }
        val out = audio.toByteArray()
        if (out.isEmpty()) throw Exception("bo'sh javob")
        return out
    }

    private fun synthesizeWithRetry(text: String, ratePercent: Int): ByteArray {
        var last: Exception? = null
        repeat(3) {
            try { return synthesize(text, ratePercent) } catch (e: Exception) {
                last = e
                Thread.sleep(600)
            }
        }
        lastError = last?.message ?: "noma'lum xato"
        throw last ?: Exception("xato")
    }

    /** Barcha bo'laklar uchun mp3 yuklab oladi. Natija: bo'lak indeksi -> fayl. */
    suspend fun prefetch(
        dir: File,
        prefix: String,
        segs: List<Seg>,
        onProgress: (Int) -> Unit
    ): Map<Int, File> = withContext(Dispatchers.IO) {
        lastError = ""
        dir.listFiles()?.filter { it.name.endsWith(".mp3") && !it.name.startsWith(prefix) }?.forEach { it.delete() }
        val sem = Semaphore(3)
        val done = AtomicInteger(0)
        val result = coroutineScope {
            segs.mapIndexed { i, seg ->
                async {
                    sem.withPermit {
                        val f = File(dir, "${prefix}_v4_$i.mp3")
                        try {
                            if (!f.exists() || f.length() == 0L) {
                                val dur = (seg.end - seg.start).coerceAtLeast(0.8f)
                                val need = seg.text.length / (dur * 14f)
                                val rate = ((need - 1f) * 100f).toInt().coerceIn(0, 40)
                                f.writeBytes(synthesizeWithRetry(seg.text, rate))
                            }
                        } catch (e: Exception) {
                            f.delete()
                        }
                        val n = done.incrementAndGet()
                        if (n % 3 == 0) onProgress(n)
                        if (f.exists() && f.length() > 0) i to f else null
                    }
                }
            }.awaitAll()
        }
        result.filterNotNull().toMap()
    }
}
