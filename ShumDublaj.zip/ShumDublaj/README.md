# ShumDublaj (Android MVP)

1. Android Studio (Koala yoki yangiroq) da `ShumDublaj` papkasini oching (File > Open).
2. Gradle sync tugashini kuting (JDK 17 — Studio bilan birga keladi).
3. Telefonni USB bilan ulang (Developer options > USB debugging) va Run ▶ bosing.
   APK kerak bo'lsa: Build > Build APK(s).
4. Telefonda: Sozlamalar > Til > Matndan nutqqa (Google TTS) > o'zbek (uz-UZ) ovozini yuklang.
5. YouTube'da video > Ulashish > ShumDublaj. Tayyor bo'lgach Play bosing.

Cheklovlar: subtitri bor videolar; embed taqiqlangan videolar ijro etilmaydi.
