package uz.shumdublaj.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicInteger

/** Telefonda o'zbekcha TTS bo'lmasa, onlayn o'zbek ovozini mp3 qilib oladi. */
object OnlineTts {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private fun split(text: String, max: Int = 170): List<String> {
        val parts = mutableListOf<String>()
        val cur = StringBuilder()
        for (w in text.split(" ")) {
            if (cur.isNotEmpty() && cur.length + 1 + w.length > max) {
                parts.add(cur.toString()); cur.clear()
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(w)
        }
        if (cur.isNotBlank()) parts.add(cur.toString())
        return parts
    }

    private fun fetchPart(part: String): ByteArray {
        val q = URLEncoder.encode(part, "UTF-8")
        val url = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=uz&q=$q"
        var last: Exception? = null
        repeat(3) {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 20000
                c.setRequestProperty("User-Agent", UA)
                c.setRequestProperty("Referer", "https://translate.google.com/")
                if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
                return c.inputStream.use { it.readBytes() }
            } catch (e: Exception) {
                last = e
                Thread.sleep(500)
            }
        }
        throw Exception(last?.message ?: "TTS xatosi")
    }

    private fun fetch(text: String): ByteArray {
        val out = ByteArrayOutputStream()
        for (p in split(text)) out.write(fetchPart(p))
        return out.toByteArray()
    }

    /** Barcha bo'laklar uchun mp3 yuklab oladi. Natija: bo'lak indeksi -> fayl. */
    suspend fun prefetch(
        dir: File,
        prefix: String,
        segs: List<Seg>,
        onProgress: (Int) -> Unit
    ): Map<Int, File> = withContext(Dispatchers.IO) {
        dir.listFiles()?.filter { it.name.endsWith(".mp3") && !it.name.startsWith(prefix) }?.forEach { it.delete() }
        val sem = Semaphore(4)
        val done = AtomicInteger(0)
        val result = coroutineScope {
            segs.mapIndexed { i, seg ->
                async {
                    sem.withPermit {
                        val f = File(dir, "${prefix}_$i.mp3")
                        try {
                            if (!f.exists() || f.length() == 0L) f.writeBytes(fetch(seg.text))
                        } catch (e: Exception) {
                            f.delete()
                        }
                        val n = done.incrementAndGet()
                        if (n % 5 == 0) onProgress(n)
                        if (f.exists() && f.length() > 0) i to f else null
                    }
                }
            }.awaitAll()
        }
        result.filterNotNull().toMap()
    }
}
