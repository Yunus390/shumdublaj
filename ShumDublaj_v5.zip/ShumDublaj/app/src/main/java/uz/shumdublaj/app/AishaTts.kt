package uz.shumdublaj.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** Aisha (aisha.group) o'zbek TTS API. Kalit: https://space.aisha.group */
object AishaTts {
    private const val BASE = "https://back.aisha.group"

    @Volatile var lastError: String = ""

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun findAudioUrl(node: Any?): String? {
        when (node) {
            is JSONObject -> {
                val keys = node.keys().asSequence().toList()
                for (k in keys) {
                    val v = node.opt(k)
                    if (v is String) {
                        val lk = k.lowercase(Locale.ROOT)
                        val looksAudio = v.startsWith("http") || v.startsWith("/") ||
                            v.endsWith(".wav") || v.endsWith(".mp3") || v.endsWith(".ogg")
                        if (looksAudio && (lk.contains("audio") || lk.contains("url") || lk.contains("path") || lk.contains("file"))) return v
                    }
                }
                for (k in keys) {
                    val r = findAudioUrl(node.opt(k))
                    if (r != null) return r
                }
            }
            is JSONArray -> for (i in 0 until node.length()) {
                val r = findAudioUrl(node.opt(i))
                if (r != null) return r
            }
        }
        return null
    }

    private fun synth(text: String, key: String, speed: Float): ByteArray {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("transcript", text.take(1000))
            .addFormDataPart("language", "uz")
            .addFormDataPart("model", "Gulnoza")
            .addFormDataPart("mood", "Neutral")
            .addFormDataPart("speed", String.format(Locale.US, "%.1f", speed))
            .build()
        val req = Request.Builder().url("$BASE/api/v1/tts/post/")
            .header("X-Api-Key", key)
            .header("Accept-Language", "uz")
            .post(body).build()

        var audioUrl: String? = null
        client.newCall(req).execute().use { r ->
            val txt = r.body?.string() ?: ""
            if (!r.isSuccessful) throw Exception("HTTP ${r.code} ${txt.take(140)}")
            audioUrl = findAudioUrl(JSONObject(txt))
            if (audioUrl == null) throw Exception("audio havolasi topilmadi: ${txt.take(140)}")
        }
        val u = audioUrl!!
        val full = if (u.startsWith("http")) u else BASE + (if (u.startsWith("/")) u else "/$u")
        var bytes = ByteArray(0)
        client.newCall(Request.Builder().url(full).build()).execute().use { a ->
            if (!a.isSuccessful) throw Exception("audio HTTP ${a.code}")
            bytes = a.body?.bytes() ?: ByteArray(0)
        }
        if (bytes.isEmpty()) throw Exception("bo'sh audio")
        return bytes
    }

    private fun synthWithRetry(text: String, key: String, speed: Float): ByteArray {
        var last: Exception? = null
        repeat(2) {
            try { return synth(text, key, speed) } catch (e: Exception) {
                last = e
                // kalit xato bo'lsa qayta urinmaymiz
                if (e.message?.startsWith("HTTP 401") == true || e.message?.startsWith("HTTP 403") == true) {
                    lastError = e.message ?: ""
                    throw e
                }
                Thread.sleep(700)
            }
        }
        lastError = last?.message ?: "noma'lum xato"
        throw last ?: Exception("xato")
    }

    /** Berilgan bo'laklar oralig'i uchun audio yuklab oladi: indeks -> fayl. */
    suspend fun prefetch(
        dir: File,
        prefix: String,
        key: String,
        segs: List<Seg>,
        range: IntRange,
        onProgress: (Int, Int) -> Unit
    ): Map<Int, File> = withContext(Dispatchers.IO) {
        val total = range.count()
        val sem = Semaphore(3)
        val done = AtomicInteger(0)
        val result = coroutineScope {
            range.map { i ->
                async {
                    sem.withPermit {
                        val seg = segs[i]
                        val f = File(dir, "${prefix}_a_$i.wav")
                        try {
                            if (!f.exists() || f.length() == 0L) {
                                val dur = (seg.end - seg.start).coerceAtLeast(0.8f)
                                val speed = (seg.text.length / (dur * 14f)).coerceIn(1.0f, 1.5f)
                                f.writeBytes(synthWithRetry(seg.text, key, speed))
                            }
                        } catch (e: Exception) {
                            f.delete()
                        }
                        onProgress(done.incrementAndGet(), total)
                        if (f.exists() && f.length() > 0) i to f else null
                    }
                }
            }.awaitAll()
        }
        result.filterNotNull().toMap()
    }
}
